package com.example.vcare.notifications

class Data(
    private var user: String,
    private var icon: Int,
    private var body: String,
    private var title: String,
    private var sented: String
)
