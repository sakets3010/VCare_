package com.example.vcare.notifications

class MyResponse {

    var success = 0
}