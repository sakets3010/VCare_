package com.example.vcare.helper

data class Id(var Id:String?="")