package com.example.vcare.notifications

import android.annotation.TargetApi
import android.app.ActivityManager
import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import androidx.annotation.RequiresApi
import androidx.core.app.Person
import com.example.vcare.helper.HelperActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessaging() : FirebaseMessagingService() {
    val KEY_TEXT_REPLY = "key_text_reply"
    override fun onMessageReceived(mRemoteMessage: RemoteMessage) {

        super.onMessageReceived(mRemoteMessage)

        val sented = mRemoteMessage.data["sented"]
        val user = mRemoteMessage.data["user"]
        val sharedPref = getSharedPreferences("PREFS", Context.MODE_PRIVATE)
        val currentOnlineUser = sharedPref.getString("currentUser", "none")
        val firebaseUser = FirebaseAuth.getInstance().currentUser

        if (firebaseUser !== null && sented == firebaseUser.uid) {
            if (currentOnlineUser !== user) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    sendOreoNotification(mRemoteMessage)
                }
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.KITKAT_WATCH)
    private fun sendOreoNotification(mRemoteMessage: RemoteMessage) {

        val user = mRemoteMessage.data["user"]
        val title = mRemoteMessage.data["title"]
        val icon = mRemoteMessage.data["icon"]
        val body = mRemoteMessage.data["body"]
        //val timeStamp = mRemoteMessage.data["timeStamp"]
        val sented = mRemoteMessage.data["sented"]

        val replyLabel = "Enter your reply here"
        val remoteInput = RemoteInput.Builder(KEY_TEXT_REPLY)
            .setLabel(replyLabel)
            .build()


        val j = user!!.replace("[\\D]".toRegex(), "").toInt()
        val intent = Intent(this, HelperActivity::class.java)
        val bundle = Bundle()
        val pendingIntent =
            PendingIntent.getActivity(this, j, intent, PendingIntent.FLAG_ONE_SHOT)
        bundle.putString("userid", user)
        intent.putExtras(bundle)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)


        var i = 0
        if (j > 0) {
            i = j
        }
        val oreoNotification = OreoNotification(this)
        if (!appInForeground(applicationContext)) {

            val defaultSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            val icon_ = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                Icon.createWithResource(applicationContext,
                    android.R.drawable.ic_dialog_info)
            } else {
                TODO("VERSION.SDK_INT < M")
            }

            val replyAction = Notification.Action.Builder(
                icon_,
                "Reply", pendingIntent)
                .addRemoteInput(remoteInput)
                .build()
            val userP = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                android.app.Person.Builder().setName(user).build()
            } else {
                TODO("VERSION.SDK_INT < P")
            }
            val style = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
              //  Notification.MessagingStyle(userP).addMessage(body,timeStamp,"saket")
            } else {
                TODO("VERSION.SDK_INT < N")
            }

            val builder: Notification.Builder =
                oreoNotification.getOreoNotification(title, body, pendingIntent, defaultSound, icon,replyAction)

            oreoNotification.getManager!!.notify(i, builder.build())
        } else {
            oreoNotification.getManager!!.cancel(i)
        }


    }



    private fun appInForeground(context: Context): Boolean {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val runningAppProcesses = activityManager.runningAppProcesses ?: return false
        return runningAppProcesses.any { it.processName == context.packageName && it.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND }
    }

}