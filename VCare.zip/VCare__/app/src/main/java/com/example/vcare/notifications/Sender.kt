package com.example.vcare.notifications

class Sender(var data: Data, var to:String)