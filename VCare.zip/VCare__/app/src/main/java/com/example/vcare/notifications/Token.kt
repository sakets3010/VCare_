package com.example.vcare.notifications

class Token(private var token: String="") {
    fun getToken():String?{
        return token
    }
}